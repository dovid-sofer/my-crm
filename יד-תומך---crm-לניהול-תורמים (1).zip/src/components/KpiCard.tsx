import React from 'react';
import { LucideIcon } from 'lucide-react';

interface KpiCardProps {
  title: string;
  value: string;
  subtitle?: string;
  trend?: string;
  trendUp?: boolean;
  colorClass: string;
  icon?: LucideIcon;
  progress?: number;
}

export const KpiCard: React.FC<KpiCardProps> = ({ 
  title, value, subtitle, trend, trendUp, colorClass, icon: Icon, progress 
}) => {
  return (
    <div className={`bg-white p-5 rounded-xl border-r-4 ${colorClass} shadow-sm`}>
      <div className="flex justify-between items-start">
        <div>
          <p className="text-xs font-bold text-on-surface-variant mb-1">{title}</p>
          <p className="text-3xl font-black text-secondary font-headline">{value}</p>
        </div>
        {Icon && <Icon className="w-5 h-5 text-on-surface-variant/50" />}
      </div>
      
      {trend && (
        <p className={`text-[10px] font-bold mt-2 flex items-center gap-1 ${trendUp ? 'text-green-600' : 'text-red-600'}`}>
          {trend}
        </p>
      )}
      
      {subtitle && !trend && (
        <p className="text-[10px] text-on-surface-variant font-bold mt-2">{subtitle}</p>
      )}

      {progress !== undefined && (
        <div className="w-full bg-surface-container h-1 rounded-full mt-3 overflow-hidden">
          <div 
            className="bg-primary-container h-full transition-all duration-500" 
            style={{ width: `${progress}%` }}
          />
        </div>
      )}
    </div>
  );
};
