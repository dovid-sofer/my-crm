import React, { useState } from 'react';
import { Lock, ArrowLeft } from 'lucide-react';
import { motion } from 'motion/react';

interface LoginScreenProps {
  onLogin: (password: string) => boolean;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  const [password, setPassword] = useState('');
  const [error, setError] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (onLogin(password)) {
      setError(false);
    } else {
      setError(true);
      setPassword('');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-secondary p-4 relative overflow-hidden">
      {/* Background Decoration */}
      <div className="absolute top-[-10%] right-[-10%] w-96 h-96 bg-primary/20 rounded-full blur-3xl" />
      <div className="absolute bottom-[-10%] left-[-10%] w-96 h-96 bg-primary-container/10 rounded-full blur-3xl" />

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white w-full max-w-md rounded-2xl shadow-2xl p-8 z-10 border border-white/20"
      >
        <div className="flex flex-col items-center mb-8">
          <div className="w-20 h-20 bg-primary-container/10 rounded-full flex items-center justify-center mb-4">
            <Lock className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-3xl font-black text-secondary font-headline tracking-tight">כניסה למערכת</h1>
          <p className="text-on-surface-variant font-medium mt-2">יד תומך - CRM לניהול תורמים</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold text-secondary block mr-1">סיסמת כניסה</label>
            <input 
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="הכנס סיסמה..."
              className={`w-full bg-surface-container-low border-2 ${error ? 'border-error' : 'border-transparent'} focus:border-primary focus:ring-0 rounded-xl px-4 py-3 text-center text-xl transition-all outline-none`}
              autoFocus
            />
            {error && (
              <motion.p 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-error text-xs font-bold text-center mt-2"
              >
                סיסמה שגויה, נסה שוב
              </motion.p>
            )}
          </div>

          <button 
            type="submit"
            className="w-full editorial-ledger-gradient text-white font-bold py-4 rounded-xl shadow-lg shadow-primary/20 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-2"
          >
            <span>התחברות</span>
            <ArrowLeft className="w-5 h-5" />
          </button>
        </form>

        <div className="mt-8 pt-6 border-t border-outline-variant/15 text-center">
          <p className="text-[10px] text-on-surface-variant font-bold uppercase tracking-widest">
            מערכת מאובטחת • כל הזכויות שמורות ליד תומך
          </p>
        </div>
      </motion.div>
    </div>
  );
};
