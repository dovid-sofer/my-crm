import React from 'react';
import { Menu } from 'lucide-react';

export const TopNav: React.FC = () => {
  return (
    <header className="bg-secondary text-white sticky top-0 flex flex-row-reverse justify-between items-center w-full px-6 h-16 z-50 shadow-md">
      <div className="flex items-center gap-4 flex-row-reverse">
        <h1 className="text-xl font-bold text-white">יד תומך</h1>
        <button className="p-2 hover:bg-white/10 rounded-full transition-colors">
          <Menu className="w-6 h-6 text-primary-container" />
        </button>
      </div>
      <div className="flex items-center gap-4">
        <div className="hidden md:flex gap-6 items-center px-4 flex-row-reverse">
          <a className="text-white border-b-2 border-primary-container py-1 font-medium" href="#">עסקאות</a>
          <a className="text-white/80 hover:text-white transition-colors py-1 font-medium" href="#">אנשי קשר</a>
          <a className="text-white/80 hover:text-white transition-colors py-1 font-medium" href="#">דאשבורד</a>
        </div>
        <div className="w-10 h-10 rounded-full bg-surface-container-highest flex items-center justify-center overflow-hidden border-2 border-primary-container">
          <img 
            alt="User" 
            src="https://picsum.photos/seed/admin/100/100" 
            referrerPolicy="no-referrer"
            className="w-full h-full object-cover"
          />
        </div>
      </div>
    </header>
  );
};
