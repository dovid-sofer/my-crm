import React, { useState } from 'react';
import { X, User, Smartphone, Phone, Mail, CreditCard, Lock, Save } from 'lucide-react';
import { Donor } from '../types';
import { calculateTotalMichlol, formatCurrency } from '../utils';
import { motion, AnimatePresence } from 'motion/react';

interface DonorModalProps {
  donor: Donor;
  onClose: () => void;
  onSave: (updatedDonor: Donor) => void;
}

export const DonorModal: React.FC<DonorModalProps> = ({ donor, onClose, onSave }) => {
  const [editedDonor, setEditedDonor] = useState<Donor>({ ...donor });
  const [pin, setPin] = useState('');
  const [showCredit, setShowCredit] = useState(false);
  const [pinError, setPinError] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setEditedDonor(prev => ({ ...prev, [name]: value }));
  };

  const handlePinSubmit = () => {
    if (pin === '1234') {
      setShowCredit(true);
      setPinError(false);
    } else {
      setPinError(true);
      setPin('');
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-white/85 backdrop-blur-md"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 20 }}
        animate={{ scale: 1, y: 0 }}
        exit={{ scale: 0.9, y: 20 }}
        className="bg-white w-full max-w-5xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]"
      >
        {/* Header */}
        <div className="bg-surface-container-high px-8 py-4 flex flex-row-reverse justify-between items-center border-b border-outline-variant/15">
          <div className="flex items-center gap-3 flex-row-reverse">
            <User className="text-primary w-8 h-8" />
            <h2 className="text-xl font-bold text-secondary">כרטיס תורם: {donor.firstName} {donor.lastName}</h2>
          </div>
          <button 
            onClick={onClose}
            className="bg-error hover:bg-error/90 text-white w-8 h-8 rounded-full flex items-center justify-center transition-transform active:scale-90"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-8 overflow-y-auto custom-scrollbar flex-1">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Right Column: Identity & Address */}
            <div className="space-y-6">
              <div className="bg-surface-container-low p-6 rounded-xl space-y-4">
                <h3 className="font-bold text-primary border-r-4 border-primary pr-3 leading-none">פרטי זהות וכתובת</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-on-surface-variant block">מספר זיהוי / ת.ז</label>
                    <input 
                      name="idNumber"
                      value={editedDonor.idNumber}
                      onChange={handleInputChange}
                      className="w-full bg-surface-container-highest border-none border-b-2 border-transparent focus:border-primary focus:ring-0 rounded-t-lg transition-all px-3 py-2 text-on-surface" 
                      type="text" 
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-on-surface-variant block">עיר</label>
                    <input 
                      name="city"
                      value={editedDonor.city}
                      onChange={handleInputChange}
                      className="w-full bg-surface-container-highest border-none border-b-2 border-transparent focus:border-primary focus:ring-0 rounded-t-lg transition-all px-3 py-2 text-on-surface" 
                      type="text" 
                    />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-on-surface-variant block">רחוב ומספר</label>
                  <input 
                    name="street"
                    value={editedDonor.street}
                    onChange={handleInputChange}
                    className="w-full bg-surface-container-highest border-none border-b-2 border-transparent focus:border-primary focus:ring-0 rounded-t-lg transition-all px-3 py-2 text-on-surface" 
                    type="text" 
                  />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-on-surface-variant block text-center">דירה</label>
                    <input 
                      name="apartment"
                      value={editedDonor.apartment}
                      onChange={handleInputChange}
                      className="w-full bg-surface-container-highest border-none border-b-2 border-transparent focus:border-primary focus:ring-0 rounded-t-lg transition-all px-3 py-2 text-on-surface text-center" 
                      type="text" 
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-on-surface-variant block text-center">מיקוד</label>
                    <input 
                      name="zip"
                      value={editedDonor.zip}
                      onChange={handleInputChange}
                      className="w-full bg-surface-container-highest border-none border-b-2 border-transparent focus:border-primary focus:ring-0 rounded-t-lg transition-all px-3 py-2 text-on-surface text-center" 
                      type="text" 
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-xs font-semibold text-on-surface-variant block text-center">ת.ד</label>
                    <input 
                      name="poBox"
                      value={editedDonor.poBox}
                      onChange={handleInputChange}
                      className="w-full bg-surface-container-highest border-none border-b-2 border-transparent focus:border-primary focus:ring-0 rounded-t-lg transition-all px-3 py-2 text-on-surface text-center" 
                      type="text" 
                    />
                  </div>
                </div>
              </div>

              {/* Total Michlol Box */}
              <div className="bg-primary-container/10 border border-primary/20 p-6 rounded-xl flex items-center justify-between">
                <div>
                  <h4 className="text-primary font-bold text-lg">סה"כ מכלול</h4>
                  <p className="text-sm text-on-surface-variant">יתרת חוב מצטברת כוללת</p>
                </div>
                <div className="text-left">
                  <span className="text-4xl font-black text-primary">{formatCurrency(calculateTotalMichlol(editedDonor))}</span>
                </div>
              </div>
            </div>

            {/* Left Column: Communication & Credit */}
            <div className="space-y-6">
              <div className="bg-surface-container-low p-6 rounded-xl space-y-4 h-full">
                <h3 className="font-bold text-primary border-r-4 border-primary pr-3 leading-none">דרכי התקשרות</h3>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-on-surface-variant block">טלפון נייד ראשי</label>
                  <div className="relative">
                    <input 
                      name="phone"
                      value={editedDonor.phone}
                      onChange={handleInputChange}
                      className="w-full bg-surface-container-highest border-none border-b-2 border-transparent focus:border-primary focus:ring-0 rounded-t-lg transition-all px-3 py-2 text-on-surface pr-10" 
                      type="tel" 
                    />
                    <Smartphone className="absolute right-3 top-2.5 w-5 h-5 text-secondary/50" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-on-surface-variant block">טלפון נוסף</label>
                  <div className="relative">
                    <input 
                      name="phone2"
                      value={editedDonor.phone2}
                      onChange={handleInputChange}
                      className="w-full bg-surface-container-highest border-none border-b-2 border-transparent focus:border-primary focus:ring-0 rounded-t-lg transition-all px-3 py-2 text-on-surface pr-10" 
                      type="tel" 
                    />
                    <Phone className="absolute right-3 top-2.5 w-5 h-5 text-secondary/50" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-xs font-semibold text-on-surface-variant block">דואר אלקטרוני</label>
                  <div className="relative">
                    <input 
                      name="email"
                      value={editedDonor.email}
                      onChange={handleInputChange}
                      className="w-full bg-surface-container-highest border-none border-b-2 border-transparent focus:border-primary focus:ring-0 rounded-t-lg transition-all px-3 py-2 text-on-surface pr-10" 
                      type="email" 
                    />
                    <Mail className="absolute right-3 top-2.5 w-5 h-5 text-secondary/50" />
                  </div>
                </div>

                <div className="pt-4 border-t border-outline-variant/15">
                  <div className="flex items-center gap-2 mb-4">
                    <Lock className="w-4 h-4 text-error" />
                    <span className="text-sm font-semibold">אבטחת כרטיס אשראי</span>
                  </div>
                  
                  <div className="space-y-4">
                    {!showCredit ? (
                      <>
                        <button 
                          onClick={handlePinSubmit}
                          className="w-full bg-error hover:bg-error/90 text-white font-bold py-3 rounded-lg flex items-center justify-center gap-2 transition-all active:scale-95 shadow-md"
                        >
                          <CreditCard className="w-5 h-5" />
                          פרטי כרטיס אשראי
                        </button>
                        <div className="space-y-1">
                          <label className={`text-xs font-semibold block ${pinError ? 'text-error' : 'text-on-surface-variant'}`}>
                            {pinError ? 'קוד שגוי, נסה שוב' : 'הקש קוד זיהוי (PIN) לצפייה'}
                          </label>
                          <input 
                            type="password"
                            maxLength={4}
                            value={pin}
                            onChange={(e) => setPin(e.target.value)}
                            placeholder="****"
                            className="w-full bg-surface-container-highest border-2 border-transparent focus:border-error focus:ring-0 rounded-lg px-3 py-2 text-center text-xl tracking-[1em]"
                          />
                        </div>
                      </>
                    ) : (
                      <div className="bg-surface-container-highest p-4 rounded-lg border-2 border-primary/20">
                        <p className="text-xs font-bold text-on-surface-variant mb-1">מספר כרטיס</p>
                        <p className="text-lg font-mono font-bold text-secondary">{editedDonor.creditCard}</p>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-6 bg-surface-container border-t border-outline-variant/15 flex flex-row-reverse justify-end gap-4">
          <button 
            onClick={() => onSave(editedDonor)}
            className="px-10 py-3 bg-primary text-white font-bold rounded-lg shadow-lg shadow-primary/20 hover:scale-[1.02] transition-all active:scale-95 flex items-center gap-2"
          >
            <Save className="w-5 h-5" />
            שמירת שינויים
          </button>
          <button 
            onClick={onClose}
            className="px-8 py-3 bg-white text-secondary font-bold border border-secondary/20 rounded-lg hover:bg-surface-container-low transition-all"
          >
            ביטול
          </button>
        </div>
      </motion.div>
    </motion.div>
  );
};
