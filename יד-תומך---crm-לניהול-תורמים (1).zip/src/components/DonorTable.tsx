import React, { useState } from 'react';
import { Search, Filter, Download, Edit2, Eye, ChevronRight, ChevronLeft, UserPlus } from 'lucide-react';
import { Donor } from '../types';
import { calculateTotalMichlol, formatCurrency } from '../utils';

interface DonorTableProps {
  donors: Donor[];
  onEdit: (donor: Donor) => void;
}

export const DonorTable: React.FC<DonorTableProps> = ({ donors, onEdit }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredDonors = donors.filter(d => 
    `${d.firstName} ${d.lastName}`.includes(searchTerm) || 
    d.id.includes(searchTerm) || 
    d.phone.includes(searchTerm)
  );

  return (
    <div className="flex flex-col gap-6">
      {/* Action Bar */}
      <section className="flex flex-wrap items-center justify-between gap-4 bg-surface-container-low p-4 rounded-xl">
        <div className="flex flex-col">
          <h1 className="text-2xl font-extrabold text-primary font-headline tracking-tight">ניהול אנשי קשר</h1>
          <p className="text-sm text-on-surface-variant">צפייה ועריכה של רשימת התורמים והפעילים</p>
        </div>
        <div className="flex gap-2">
          <button className="flex flex-col items-center justify-center p-2 rounded-xl bg-white hover:bg-surface-container-low transition-all shadow-sm group">
            <div className="w-10 h-10 rounded-full bg-primary-container/10 text-primary flex items-center justify-center mb-1 group-hover:scale-110 duration-200">
              <UserPlus className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-on-surface-variant">הוספת איש קשר</span>
          </button>
          <button className="flex flex-col items-center justify-center p-2 rounded-xl bg-white hover:bg-surface-container-low transition-all shadow-sm group">
            <div className="w-10 h-10 rounded-full bg-primary-container/10 text-primary flex items-center justify-center mb-1 group-hover:scale-110 duration-200">
              <Download className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold text-on-surface-variant">ייצוא לאקסל</span>
          </button>
        </div>
      </section>

      {/* Search & Filter */}
      <div className="bg-white p-3 rounded-t-xl border border-outline-variant/15 flex flex-wrap gap-4 items-center">
        <div className="relative flex-grow max-w-md">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 text-on-surface-variant w-5 h-5" />
          <input 
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="חיפוש לפי שם, טלפון או מזהה..."
            className="w-full pr-10 pl-4 py-2 border border-outline-variant/30 rounded-lg text-sm focus:ring-2 focus:ring-primary-container focus:border-transparent outline-none"
          />
        </div>
        <select className="bg-surface-container-low border border-outline-variant/30 rounded-lg px-3 py-2 text-sm text-on-surface-variant outline-none">
          <option>כל הסטטוסים</option>
          <option>פעיל</option>
          <option>לא פעיל</option>
        </select>
        <button className="mr-auto text-primary-container font-bold text-sm flex items-center gap-1 hover:underline">
          <Filter className="w-4 h-4" />
          סינון מתקדם
        </button>
      </div>

      {/* Table */}
      <div className="bg-white shadow-xl rounded-b-xl overflow-hidden border border-t-0 border-outline-variant/15">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse">
            <thead>
              <tr className="bg-primary-container text-white text-sm font-bold">
                <th className="py-3 px-4 text-center w-16">ערוך</th>
                <th className="py-3 px-4 border-r border-white/20">מזהה</th>
                <th className="py-3 px-4 border-r border-white/20">שם מלא</th>
                <th className="py-3 px-4 border-r border-white/20">כתובת מגורים</th>
                <th className="py-3 px-4 border-r border-white/20">טלפון</th>
                <th className="py-3 px-4 border-r border-white/20">סה"כ מכלול</th>
                <th className="py-3 px-4 border-r border-white/20">סטטוס</th>
              </tr>
            </thead>
            <tbody className="text-sm font-medium">
              {filteredDonors.map((donor, idx) => (
                <tr key={donor.id} className={`border-b border-outline-variant/10 hover:bg-surface-container-low transition-colors ${idx % 2 === 1 ? 'bg-surface-container-low/30' : ''}`}>
                  <td className="py-2 px-4 text-center">
                    <button 
                      onClick={() => onEdit(donor)}
                      className="p-1.5 text-secondary hover:bg-primary-container/10 rounded-md transition-colors"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                  </td>
                  <td className="py-2 px-4 text-on-surface-variant font-mono">{donor.id}</td>
                  <td className="py-2 px-4 font-bold text-secondary">{donor.firstName} {donor.lastName}</td>
                  <td className="py-2 px-4 text-on-surface-variant">{donor.street}, {donor.city}</td>
                  <td className="py-2 px-4 text-on-surface-variant dir-ltr">{donor.phone}</td>
                  <td className="py-2 px-4 font-bold text-primary">{formatCurrency(calculateTotalMichlol(donor))}</td>
                  <td className="py-2 px-4">
                    <span className="px-2 py-0.5 bg-green-100 text-green-800 rounded-full text-[11px] font-bold">פעיל</span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        {/* Pagination */}
        <div className="flex items-center justify-between px-6 py-3 bg-surface-container-low border-t border-outline-variant/15">
          <p className="text-xs text-on-surface-variant font-bold">מציג 1-{filteredDonors.length} מתוך {donors.length} אנשי קשר</p>
          <div className="flex gap-1">
            <button className="w-8 h-8 flex items-center justify-center rounded border border-outline-variant/30 hover:bg-white transition-colors">
              <ChevronRight className="w-4 h-4" />
            </button>
            <button className="w-8 h-8 flex items-center justify-center rounded bg-primary text-white font-bold text-xs">1</button>
            <button className="w-8 h-8 flex items-center justify-center rounded border border-outline-variant/30 hover:bg-white transition-colors text-xs font-bold">2</button>
            <button className="w-8 h-8 flex items-center justify-center rounded border border-outline-variant/30 hover:bg-white transition-colors">
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
