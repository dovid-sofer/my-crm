import React from 'react';
import { TrendingUp, TrendingDown, Users, Target, Handshake, AlertCircle } from 'lucide-react';
import { KpiCard } from './KpiCard';
import { Donor } from '../types';
import { calculateTotalMichlol, formatCurrency } from '../utils';

interface DashboardProps {
  donors: Donor[];
}

export const Dashboard: React.FC<DashboardProps> = ({ donors }) => {
  const totalGeviya = donors.reduce((sum, d) => sum + calculateTotalMichlol(d), 0);
  
  return (
    <div className="space-y-8">
      {/* KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="md:col-span-2">
          <KpiCard 
            title="סך גביה שנתית"
            value={formatCurrency(totalGeviya)}
            trend="+12.5% מהשנה שעברה"
            trendUp={true}
            colorClass="border-primary"
            progress={75}
            subtitle="75% מהיעד השנתי הושג"
          />
        </div>
        <KpiCard 
          title="יעד חודשי"
          value={formatCurrency(120000)}
          trend="-2% מהחודש הקודם"
          trendUp={false}
          colorClass="border-secondary"
          icon={Target}
        />
        <KpiCard 
          title="הוראות קבע פעילות"
          value="842"
          subtitle="גידול של 14 מנויים השבוע"
          colorClass="border-primary-container"
          icon={Handshake}
        />
      </div>

      {/* Secondary Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Recent Activity */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm overflow-hidden border border-outline-variant/15">
          <div className="bg-primary-container px-6 py-4 flex justify-between items-center">
            <h2 className="text-white font-black text-lg uppercase tracking-wider">פעילות אחרונה</h2>
            <TrendingUp className="text-white w-5 h-5" />
          </div>
          <div className="p-4">
            <div className="space-y-4">
              {[
                { name: 'אברהם כהן', type: 'תרומה חד פעמית', amount: 500, date: '14/05/2024', status: 'הושלם' },
                { name: 'שרה לוי', type: 'הוראת קבע', amount: 120, date: '14/05/2024', status: 'הושלם' },
                { name: 'יעקב ישראלי', type: 'נדרים פלוס', amount: 1200, date: '13/05/2024', status: 'ממתין' },
                { name: 'רבקה אהרוני', type: 'העברה בנקאית', amount: 2500, date: '13/05/2024', status: 'הושלם' },
              ].map((activity, i) => (
                <div key={i} className="flex items-center justify-between p-3 hover:bg-surface-container-low rounded-lg transition-colors border-b border-outline-variant/10 last:border-0">
                  <div className="flex flex-col">
                    <span className="font-bold text-secondary">{activity.name}</span>
                    <span className="text-xs text-on-surface-variant">{activity.type} • {activity.date}</span>
                  </div>
                  <div className="flex items-center gap-4">
                    <span className="font-black text-primary">{formatCurrency(activity.amount)}</span>
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                      activity.status === 'הושלם' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'
                    }`}>
                      {activity.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-4 py-2 text-primary font-bold text-sm hover:underline">צפה בכל הפעילויות</button>
          </div>
        </div>

        {/* Insights & Tasks */}
        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-sm p-6 border border-outline-variant/15">
            <h2 className="text-secondary font-black text-lg mb-6">תובנות מערכת</h2>
            <div className="space-y-6">
              <div className="flex gap-4 items-start">
                <div className="w-10 h-10 rounded-lg bg-secondary-container/30 flex items-center justify-center text-secondary shrink-0">
                  <TrendingUp className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-bold text-secondary">הזדמנות להגדלת גביה</p>
                  <p className="text-xs text-on-surface-variant leading-relaxed">זיהינו 12 תורמים שסיימו הוראת קבע בחודש האחרון. כדאי ליצור קשר.</p>
                </div>
              </div>
              <div className="flex gap-4 items-start">
                <div className="w-10 h-10 rounded-lg bg-primary-container/20 flex items-center justify-center text-primary shrink-0">
                  <AlertCircle className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-bold text-secondary">משימות דחופות</p>
                  <p className="text-xs text-on-surface-variant leading-relaxed">ישנן 3 תרומות שנכשלו הבוקר הדורשות טיפול מיידי.</p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-secondary text-white rounded-xl shadow-sm p-6">
            <h2 className="font-black text-lg mb-4">משימות לביצוע</h2>
            <div className="space-y-3">
              {['שיחה לחידוש תרומה - משפחת כהן', 'הפקת דוח רבעוני', 'טיפול בתרומות שנכשלו'].map((task, i) => (
                <label key={i} className="flex items-center gap-3 cursor-pointer group">
                  <input type="checkbox" className="rounded-sm border-white/30 bg-transparent text-primary-container focus:ring-primary-container h-4 w-4" />
                  <span className="text-sm text-white/80 group-hover:text-white transition-colors">{task}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
