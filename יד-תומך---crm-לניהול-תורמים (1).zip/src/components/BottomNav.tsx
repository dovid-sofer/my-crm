import React from 'react';
import { LayoutDashboard, Users, Handshake, Settings } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab }) => {
  const tabs = [
    { id: 'dashboard', label: 'דאשבורד', icon: LayoutDashboard },
    { id: 'donors', label: 'אנשי קשר', icon: Users },
    { id: 'deals', label: 'עסקאות', icon: Handshake },
    { id: 'settings', label: 'הגדרות', icon: Settings },
  ];

  return (
    <nav className="fixed bottom-0 w-full z-50 flex flex-row-reverse justify-around items-center px-4 py-2 bg-background shadow-[0_-4px_12px_rgba(59,86,110,0.05)] md:hidden border-t border-outline-variant/15">
      {tabs.map((tab) => {
        const Icon = tab.icon;
        const isActive = activeTab === tab.id;
        return (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex flex-col items-center justify-center px-4 py-1 rounded-xl transition-all active:scale-90 ${
              isActive ? 'bg-primary-container/10 text-primary' : 'text-secondary'
            }`}
          >
            <Icon className={`w-6 h-6 ${isActive ? 'fill-current' : ''}`} />
            <span className="text-[10px] font-medium mt-1">{tab.label}</span>
          </button>
        );
      })}
    </nav>
  );
};
