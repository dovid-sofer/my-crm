import { Donor } from './types';

export const calculateTotalMichlol = (donor: Donor): number => {
  return Object.values(donor.donations).reduce((sum, val) => sum + val, 0);
};

export const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('he-IL', {
    style: 'currency',
    currency: 'ILS',
    maximumFractionDigits: 0
  }).format(amount);
};
