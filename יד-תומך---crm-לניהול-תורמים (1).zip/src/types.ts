export interface Donor {
  id: string;
  lastName: string;
  firstName: string;
  street: string;
  city: string;
  phone: string;
  phone2: string;
  community: string;
  creditCard: string;
  idNumber: string;
  apartment: string;
  zip: string;
  poBox: string;
  email: string;
  donations: Record<string, number>;
}

export const HOLIDAYS = [
  "פסח תשפ\"ג",
  "שבועות תשפ\"ג",
  "סוכות תשפ\"ד",
  "חנוכה תשפ\"ד",
  "פורים תשפ\"ד"
];
