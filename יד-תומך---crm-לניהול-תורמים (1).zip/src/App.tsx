/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { TopNav } from './components/TopNav';
import { BottomNav } from './components/BottomNav';
import { Dashboard } from './components/Dashboard';
import { DonorTable } from './components/DonorTable';
import { DonorModal } from './components/DonorModal';
import { LoginScreen } from './components/LoginScreen';
import { Donor } from './types';
import donorsData from './donors.json';
import { AnimatePresence } from 'motion/react';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [donors, setDonors] = useState<Donor[]>([]);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [selectedDonor, setSelectedDonor] = useState<Donor | null>(null);

  useEffect(() => {
    // Check if user was previously authenticated in this session
    const authStatus = sessionStorage.getItem('is_auth');
    if (authStatus === 'true') {
      setIsAuthenticated(true);
    }
    setDonors(donorsData as Donor[]);
  }, []);

  const handleLogin = (password: string) => {
    if (password === '1234') { // Using the same PIN as requested for credit card for simplicity
      setIsAuthenticated(true);
      sessionStorage.setItem('is_auth', 'true');
      return true;
    }
    return false;
  };

  const handleSaveDonor = (updatedDonor: Donor) => {
    setDonors(prev => prev.map(d => d.id === updatedDonor.id ? updatedDonor : d));
    setSelectedDonor(null);
  };

  if (!isAuthenticated) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-background pb-20 md:pb-0">
      <TopNav />
      
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 md:px-8 py-8">
        {activeTab === 'dashboard' && <Dashboard donors={donors} />}
        {activeTab === 'donors' && (
          <DonorTable 
            donors={donors} 
            onEdit={(donor) => setSelectedDonor(donor)} 
          />
        )}
        {activeTab === 'deals' && (
          <div className="flex items-center justify-center h-64 text-on-surface-variant font-bold">
            מסך עסקאות - בקרוב
          </div>
        )}
        {activeTab === 'settings' && (
          <div className="flex items-center justify-center h-64 text-on-surface-variant font-bold">
            <button 
              onClick={() => {
                setIsAuthenticated(false);
                sessionStorage.removeItem('is_auth');
              }}
              className="px-6 py-3 bg-error text-white font-bold rounded-lg"
            >
              התנתקות מהמערכת
            </button>
          </div>
        )}
      </main>

      <BottomNav activeTab={activeTab} setActiveTab={setActiveTab} />

      <AnimatePresence>
        {selectedDonor && (
          <DonorModal 
            donor={selectedDonor} 
            onClose={() => setSelectedDonor(null)} 
            onSave={handleSaveDonor}
          />
        )}
      </AnimatePresence>

      {/* Desktop Sidebar Decoration */}
      <aside className="hidden xl:flex fixed right-0 top-16 h-[calc(100vh-4rem)] w-16 bg-primary/5 border-l border-outline-variant/10 flex-col items-center py-6 gap-6">
        <div className="w-10 h-10 rounded-full bg-primary text-white flex items-center justify-center shadow-lg cursor-pointer hover:scale-110 transition-transform">
          <span className="text-xl font-bold">+</span>
        </div>
        <div className="w-10 h-10 rounded-full bg-white text-secondary border border-outline-variant/30 flex items-center justify-center cursor-pointer hover:bg-secondary hover:text-white transition-all">
          <span className="text-lg">🔔</span>
        </div>
      </aside>
    </div>
  );
}

